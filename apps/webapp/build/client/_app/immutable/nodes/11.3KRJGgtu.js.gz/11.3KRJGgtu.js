import"../chunks/disclose-version.bJ1TNjgf.js";function p(o){}export{p as component};
