import{b as a}from"../chunks/entry.F0RumkfI.js";export{a as start};
